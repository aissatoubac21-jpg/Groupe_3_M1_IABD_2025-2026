import 'package:flutter/material.dart';
import '../models/disease_info.dart';

class AppTheme {
  static const Color primaryGreen = Color(0xFF2E7D32);
  static const Color warningOrange = Color(0xFFEF6C00);
  static const Color dangerRed = Color(0xFFC62828);

  static ThemeData get theme => ThemeData(
        useMaterial3: true,
        colorSchemeSeed: primaryGreen,
        scaffoldBackgroundColor: const Color(0xFFF7F9F4),
        appBarTheme: const AppBarTheme(
          backgroundColor: primaryGreen,
          foregroundColor: Colors.white,
          centerTitle: true,
          elevation: 0,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: primaryGreen,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
        ),
      );

  static Color colorForSeverity(Severity s) {
    switch (s) {
      case Severity.sain:
        return primaryGreen;
      case Severity.moyenne:
        return warningOrange;
      case Severity.elevee:
        return dangerRed;
    }
  }
}
