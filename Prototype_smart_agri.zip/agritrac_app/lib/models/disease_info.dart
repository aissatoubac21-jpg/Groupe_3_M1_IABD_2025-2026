/// Représente une classe de diagnostic reconnue par le modèle AgriTrac.
///
/// La structure sépare volontairement le contenu affiché (français,
/// aujourd'hui) de la clé technique (`id`), afin que l'ajout d'autres
/// langues (wolof, poular, sérère — Phase 6 de la feuille de route) se
/// fasse en ajoutant des champs / une table de traduction, sans toucher
/// à la logique de classification ni à l'interface.
class DiseaseInfo {
  /// Identifiant technique — DOIT correspondre exactement aux entrées de
  /// assets/model/labels.txt (même orthographe, même ordre logique).
  final String id;

  /// Nom affiché à l'utilisateur.
  final String displayName;

  /// Courte description de la maladie / de l'état de la feuille.
  final String description;

  /// Conseils de lutte : pratiques culturales d'abord (recommandations
  /// FAO génériques, sans risque), produit chimique seulement si
  /// confirmé par un phytopathologiste — voir la note dans
  /// `recommendedProduct`.
  final List<String> culturalRecommendations;

  /// Nom d'un produit phytosanitaire spécifique, seulement s'il a été
  /// explicitement validé pour cette maladie précise. Laisser à `null`
  /// tant que l'association maladie ↔ produit n'est pas confirmée :
  /// mieux vaut ne rien afficher qu'afficher une association incorrecte
  /// dans une appli qui guide de vraies décisions de traitement.
  final String? recommendedProduct;

  /// Niveau de gravité pour l'code couleur de l'interface.
  final Severity severity;

  const DiseaseInfo({
    required this.id,
    required this.displayName,
    required this.description,
    required this.culturalRecommendations,
    required this.severity,
    this.recommendedProduct,
  });
}

enum Severity { sain, moyenne, elevee }

/// Base de connaissances statique, embarquée (fonctionne hors-ligne).
///
/// Sources : FAO — "Systèmes améliorés de riziculture pluviale" (lutte
/// intégrée contre les maladies du riz) pour les pratiques culturales.
///
/// ⚠️ Sur PELT 44, CORATOP et KITAZINE cités par le phytopathologiste du
/// projet : seul KITAZINE (matière active IBP) est documenté dans la
/// littérature FAO comme fongicide de référence contre la pyriculariose.
/// L'association précise de PELT 44 et CORATOP à une maladie donnée n'a
/// pas pu être confirmée à partir des sources disponibles ici — ne pas
/// les afficher tant que cette correspondance n'est pas validée par le
/// phytopathologiste du projet (Phase 7 de la feuille de route). Ajoute-les
/// alors simplement comme `recommendedProduct` ci-dessous.
const Map<String, DiseaseInfo> kDiseaseCatalog = {
  'sain': DiseaseInfo(
    id: 'sain',
    displayName: 'Feuille saine',
    description:
        "Aucun signe de pyriculariose ni d'helminthosporiose détecté sur "
        "cette feuille.",
    culturalRecommendations: [
      "Continuer la surveillance régulière du champ, surtout en période "
          "humide (25–30 °C, forte humidité relative).",
      "Maintenir une fertilisation équilibrée : un excès d'azote favorise "
          "la pyriculariose.",
      "Éviter le stress hydrique et les sols dégradés, associés à un "
          "risque accru d'helminthosporiose.",
    ],
    severity: Severity.sain,
  ),
  'pyriculariose': DiseaseInfo(
    id: 'pyriculariose',
    displayName: 'Pyriculariose (Pyricularia oryzae)',
    description:
        "Maladie fongique la plus répandue et la plus destructrice du riz "
        "dans le monde. Elle se manifeste par des taches en forme de "
        "losange sur les feuilles, pouvant évoluer vers une nécrose du "
        "cou de la panicule.",
    culturalRecommendations: [
      "Privilégier des variétés résistantes si disponibles localement.",
      "Éviter les excès d'azote, en particulier en couverture tardive.",
      "Aérer le peuplement (densité de semis raisonnable) pour limiter "
          "l'humidité au niveau du feuillage.",
      "Détruire les résidus de culture infectés après récolte.",
      "En cas de forte pression, un traitement fongicide ciblé "
          "(matière active de type IBP — ex. Kitazine) peut être "
          "envisagé ; demander confirmation à un technicien agricole "
          "avant application.",
    ],
    recommendedProduct: 'KITAZINE',
    severity: Severity.elevee,
  ),
  'helminthosporiose': DiseaseInfo(
    id: 'helminthosporiose',
    displayName: 'Helminthosporiose (Cochliobolus miyabeanus)',
    description:
        "Fréquente en riziculture pluviale stricte, elle provoque la "
        "flétrissure des jeunes plants et des taches brunes ovales sur "
        "les feuilles. Elle est souvent liée à un sol carencé ou dégradé.",
    culturalRecommendations: [
      "Utiliser des semences saines, traitées si possible avant semis.",
      "Corriger les carences du sol (notamment potassium) par un apport "
          "organique ou minéral adapté.",
      "Éviter les sols mal drainés ou fortement dégradés.",
      "Rotation culturale pour réduire l'inoculum dans le sol.",
      "Confirmer avec un technicien agricole avant tout traitement "
          "chimique — l'association produit/maladie doit être validée "
          "localement.",
    ],
    severity: Severity.moyenne,
  ),
};
