import 'dart:typed_data';

class DiagnosisResult {
  /// Identifiant de la classe prédite — clé dans kDiseaseCatalog.
  final String classId;

  /// Confiance du modèle pour la classe prédite, entre 0 et 1.
  final double confidence;

  /// Probabilités pour chaque classe (id -> probabilité), pour affichage
  /// détaillé si besoin.
  final Map<String, double> allProbabilities;

  final DateTime timestamp;

  /// Miniature de l'image analysée, conservée pour l'historique.
  final Uint8List thumbnail;

  const DiagnosisResult({
    required this.classId,
    required this.confidence,
    required this.allProbabilities,
    required this.timestamp,
    required this.thumbnail,
  });
}
