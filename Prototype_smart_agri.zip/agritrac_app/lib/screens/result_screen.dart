import 'package:flutter/material.dart';

import '../models/diagnosis_result.dart';
import '../models/disease_info.dart';
import '../theme/app_theme.dart';

class ResultScreen extends StatelessWidget {
  final DiagnosisResult result;

  const ResultScreen({super.key, required this.result});

  @override
  Widget build(BuildContext context) {
    final info = kDiseaseCatalog[result.classId];
    final color = info != null
        ? AppTheme.colorForSeverity(info.severity)
        : Colors.grey;
    final confidencePct = (result.confidence * 100).toStringAsFixed(1);
    final lowConfidence = result.confidence < 0.6;

    return Scaffold(
      appBar: AppBar(title: const Text('Résultat du diagnostic')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.memory(
              result.thumbnail,
              height: 220,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color, width: 1.2),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  info?.displayName ?? result.classId,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
                const SizedBox(height: 6),
                Text('Confiance du modèle : $confidencePct %'),
                if (lowConfidence) ...[
                  const SizedBox(height: 8),
                  const Text(
                    "⚠️ Confiance faible — reprends la photo avec un bon "
                    "éclairage et la feuille bien cadrée, ou fais confirmer "
                    "par un technicien agricole avant tout traitement.",
                    style: TextStyle(fontStyle: FontStyle.italic),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 20),
          if (info != null) ...[
            Text(info.description, style: const TextStyle(fontSize: 15, height: 1.4)),
            const SizedBox(height: 20),
            const Text('Recommandations', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            ...info.culturalRecommendations.map(
              (r) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('•  '),
                    Expanded(child: Text(r, style: const TextStyle(height: 1.35))),
                  ],
                ),
              ),
            ),
            if (info.recommendedProduct != null) ...[
              const SizedBox(height: 8),
              Text(
                'Produit de référence : ${info.recommendedProduct}',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              const Text(
                "Toujours vérifier la disponibilité, le dosage et les "
                "précautions d'usage auprès d'un technicien agricole.",
                style: TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ],
          ],
          const SizedBox(height: 24),
          ExpansionTile(
            title: const Text('Détail des probabilités par classe'),
            children: result.allProbabilities.entries
                .map((e) => ListTile(
                      dense: true,
                      title: Text(kDiseaseCatalog[e.key]?.displayName ?? e.key),
                      trailing: Text('${(e.value * 100).toStringAsFixed(1)} %'),
                    ))
                .toList(),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.arrow_back),
              label: const Text('Nouveau diagnostic'),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ),
        ],
      ),
    );
  }
}
