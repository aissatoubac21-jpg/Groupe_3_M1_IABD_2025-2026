import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../models/diagnosis_result.dart';
import '../services/classifier_service.dart';
import '../services/history_service.dart';
import 'result_screen.dart';

class HomeScreen extends StatefulWidget {
  final ClassifierService classifier;

  const HomeScreen({super.key, required this.classifier});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _picker = ImagePicker();
  final _history = HistoryService();
  bool _isProcessing = false;

  Future<void> _pickAndClassify(ImageSource source) async {
    try {
      final picked = await _picker.pickImage(
        source: source,
        maxWidth: 1600,
        imageQuality: 90,
      );
      if (picked == null) return;

      setState(() => _isProcessing = true);

      final DiagnosisResult result =
          await widget.classifier.classifyFile(File(picked.path));

      await _history.add(HistoryEntry(
        classId: result.classId,
        confidence: result.confidence,
        timestamp: result.timestamp,
      ));

      if (!mounted) return;
      setState(() => _isProcessing = false);

      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => ResultScreen(result: result)),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isProcessing = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur pendant le diagnostic : $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AgriTrac — Riz')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.eco, size: 96, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 16),
              const Text(
                'Diagnostic de la pyriculariose et de l\'helminthosporiose du riz',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              const Text(
                'Photographie une feuille de riz. L\'analyse se fait entièrement '
                'sur ton téléphone, même sans connexion internet.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black54),
              ),
              const SizedBox(height: 40),
              if (_isProcessing) ...[
                const CircularProgressIndicator(),
                const SizedBox(height: 12),
                const Text('Analyse en cours…'),
              ] else ...[
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.camera_alt),
                    label: const Text('Prendre une photo'),
                    onPressed: () => _pickAndClassify(ImageSource.camera),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.photo_library_outlined),
                    label: const Text('Choisir depuis la galerie'),
                    onPressed: () => _pickAndClassify(ImageSource.gallery),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
