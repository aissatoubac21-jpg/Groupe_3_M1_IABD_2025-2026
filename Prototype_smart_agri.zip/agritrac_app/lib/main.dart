import 'package:flutter/material.dart';

import 'screens/home_screen.dart';
import 'services/classifier_service.dart';
import 'theme/app_theme.dart';

void main() {
  runApp(const AgriTracApp());
}

class AgriTracApp extends StatelessWidget {
  const AgriTracApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AgriTrac',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.theme,
      home: const _AppRoot(),
    );
  }
}

/// Charge le modèle TFLite une seule fois au démarrage, puis affiche
/// l'écran principal. Séparé de HomeScreen pour que l'écran de chargement
/// reste simple et ne bloque rien d'autre pendant l'initialisation.
class _AppRoot extends StatefulWidget {
  const _AppRoot();

  @override
  State<_AppRoot> createState() => _AppRootState();
}

class _AppRootState extends State<_AppRoot> {
  final _classifier = ClassifierService();
  late final Future<void> _loadingFuture;

  @override
  void initState() {
    super.initState();
    _loadingFuture = _classifier.load();
  }

  @override
  void dispose() {
    _classifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<void>(
      future: _loadingFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Chargement du modèle AgriTrac…'),
                ],
              ),
            ),
          );
        }

        if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  "Impossible de charger le modèle de diagnostic.\n\n"
                  "${snapshot.error}",
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          );
        }

        return HomeScreen(classifier: _classifier);
      },
    );
  }
}
