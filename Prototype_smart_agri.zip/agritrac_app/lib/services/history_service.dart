import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Historique local des diagnostics — stocké uniquement sur l'appareil
/// (aucun envoi réseau). Utile pour qu'un agent terrain retrouve ses
/// derniers relevés même sans connexion.
class HistoryEntry {
  final String classId;
  final double confidence;
  final DateTime timestamp;

  HistoryEntry({required this.classId, required this.confidence, required this.timestamp});

  Map<String, dynamic> toJson() => {
        'classId': classId,
        'confidence': confidence,
        'timestamp': timestamp.toIso8601String(),
      };

  factory HistoryEntry.fromJson(Map<String, dynamic> json) => HistoryEntry(
        classId: json['classId'] as String,
        confidence: (json['confidence'] as num).toDouble(),
        timestamp: DateTime.parse(json['timestamp'] as String),
      );
}

class HistoryService {
  static const _key = 'agritrac_history_v1';
  static const _maxEntries = 100;

  Future<List<HistoryEntry>> loadAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    return raw
        .map((s) => HistoryEntry.fromJson(jsonDecode(s) as Map<String, dynamic>))
        .toList()
        .reversed
        .toList();
  }

  Future<void> add(HistoryEntry entry) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    raw.add(jsonEncode(entry.toJson()));
    final trimmed = raw.length > _maxEntries
        ? raw.sublist(raw.length - _maxEntries)
        : raw;
    await prefs.setStringList(_key, trimmed);
  }

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}
