import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart' show rootBundle;
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';

import '../models/diagnosis_result.dart';

/// Charge le modèle `agritrac_mobilenetv2_riz.tflite` et exécute
/// l'inférence entièrement sur l'appareil, sans connexion réseau.
///
/// Le modèle a été exporté depuis Keras avec le prétraitement
/// `mobilenet_v2.preprocess_input` intégré directement dans le graphe
/// (voir le notebook, Phase 3). L'entrée attendue ici est donc l'image
/// brute, pixels en 0–255, PAS déjà normalisée : ne pas diviser par 255
/// ni recentrer entre -1 et 1 côté Dart, ce serait fait deux fois.
class ClassifierService {
  static const String _modelAsset = 'assets/model/agritrac_mobilenetv2_riz.tflite';
  static const String _labelsAsset = 'assets/model/labels.txt';
  static const int _inputSize = 224;

  Interpreter? _interpreter;
  List<String>? _labels;

  bool get isReady => _interpreter != null && _labels != null;

  /// À appeler une seule fois (par exemple au démarrage de l'app).
  Future<void> load() async {
    if (isReady) return;

    final modelBytes = await rootBundle.load(_modelAsset);
    _interpreter = Interpreter.fromBuffer(modelBytes.buffer.asUint8List());

    final labelsText = await rootBundle.loadString(_labelsAsset);
    _labels = labelsText
        .split('\n')
        .map((l) => l.trim())
        .where((l) => l.isNotEmpty)
        .toList();

    // Garde-fou : si labels.txt et la sortie du modèle divergent en
    // nombre de classes, mieux vaut échouer bruyamment ici que produire
    // un diagnostic silencieusement faux.
    final outputShape = _interpreter!.getOutputTensor(0).shape;
    final numClasses = outputShape.last;
    if (numClasses != _labels!.length) {
      throw StateError(
        'Incohérence modèle/labels : le modèle produit $numClasses classes '
        'mais labels.txt en contient ${_labels!.length}.',
      );
    }
  }

  Future<DiagnosisResult> classifyFile(File imageFile) async {
    if (!isReady) {
      throw StateError('ClassifierService.load() doit être appelé avant classifyFile().');
    }

    final rawBytes = await imageFile.readAsBytes();
    return classifyBytes(rawBytes);
  }

  Future<DiagnosisResult> classifyBytes(Uint8List rawBytes) async {
    if (!isReady) {
      throw StateError('ClassifierService.load() doit être appelé avant classifyBytes().');
    }

    var decoded = img.decodeImage(rawBytes);
    if (decoded == null) {
      throw const FormatException("Image illisible : format non supporté ou fichier corrompu.");
    }

    // Applique la rotation indiquée par les métadonnées EXIF (photos de
    // téléphone) avant redimensionnement, sinon le modèle peut recevoir
    // une feuille de riz "couchée".
    decoded = img.bakeOrientation(decoded);

    final resized = img.copyResize(
      decoded,
      width: _inputSize,
      height: _inputSize,
      interpolation: img.Interpolation.linear,
    );

    // Miniature pour l'historique / l'écran de résultat — indépendante
    // de la taille d'entrée du modèle.
    final thumbnail = Uint8List.fromList(
      img.encodeJpg(img.copyResize(decoded, width: 320), quality: 80),
    );

    // Construit le tenseur d'entrée [1, 224, 224, 3] en float32, valeurs
    // brutes 0–255 (voir note en tête de fichier).
    final input = List.generate(
      1,
      (_) => List.generate(
        _inputSize,
        (y) => List.generate(
          _inputSize,
          (x) {
            final pixel = resized.getPixel(x, y);
            return [
              pixel.r.toDouble(),
              pixel.g.toDouble(),
              pixel.b.toDouble(),
            ];
          },
        ),
      ),
    );

    final numClasses = _labels!.length;
    final output = List.generate(1, (_) => List.filled(numClasses, 0.0));

    _interpreter!.run(input, output);

    final probabilities = output[0];
    var bestIndex = 0;
    for (var i = 1; i < probabilities.length; i++) {
      if (probabilities[i] > probabilities[bestIndex]) bestIndex = i;
    }

    final allProbabilities = <String, double>{
      for (var i = 0; i < _labels!.length; i++) _labels![i]: probabilities[i],
    };

    return DiagnosisResult(
      classId: _labels![bestIndex],
      confidence: probabilities[bestIndex],
      allProbabilities: allProbabilities,
      timestamp: DateTime.now(),
      thumbnail: thumbnail,
    );
  }

  void dispose() {
    _interpreter?.close();
    _interpreter = null;
  }
}
